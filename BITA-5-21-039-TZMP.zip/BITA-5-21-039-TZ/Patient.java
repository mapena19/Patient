class Patient {
    private String name, address;
    public Patient (){

    }
    public Patient(String name, String address){
        this.name=name;
        this.address=address;
    }
    public void setname(String name){
        this.name=name;
    }
    public String getname(){
        return name;
    }
    public void setaddress(String adress){
        this.address=adress;
    }
    public String getaddress(){
        return address;
    }
    @Override
    public String toString(){
        return "the name is  "+name+ "and her/his addres is  "+address; 
    }
}
