import java.util.Scanner;
class Nurse extends Patient {
    private int n_id, contact;
    private String report_info, gender;
    public Nurse(){

    }
    public Nurse(int n_id, int contact,String report_info, String gender,String name, String address){
        super(name,address);
        this.n_id=n_id;
        this.contact=contact;
        this.report_info=report_info;
        this.gender=gender;
    }
    public void setn_id(int ni_d){
        this.n_id=n_id;
    }
    public int getn_id(){
        return n_id;
    }
    public void setcontact(int contact){
        this.contact=contact;
    }
    public int getcontact(){
        return contact;
    }
    public void setreport_info(String report_info){
        this.report_info=report_info;
    }
    public String getreport_info(){
        return report_info;
    }
    public  void setgender(String gender){
        this.gender=gender;
    }
    public String getgender(){
        return gender;
    }
    @Override
    public String toString(){
        return "nurse information " +super.toString()+"the nurse id is  " +n_id+
        "the phone no of nurse is "+contact+ "the report of patient is "+report_info+ "the gender of nurse is "
        +gender; 
    }
    public static void main(String[] args) {
        Nurse nur = new Nurse();
        Scanner mam=new Scanner(System.in);
        System.out.println("enter nurse name");
        nur.setname(mam.nextLine());
        System.out.println("enter address name");
        nur.setaddress(mam.nextLine());
        System.out.println("enter  report information");
        nur.setreport_info(mam.nextLine());
        System.out.println("enter  gender of docter");
        nur.setgender(mam.nextLine());
        System.out.println("enter  id of nurse");
        nur.setn_id(mam.nextInt());
        System.out.println("enter  contact of nurse");
        nur.setcontact(mam.nextInt());
        System.out.println(nur.toString());
    }
}
