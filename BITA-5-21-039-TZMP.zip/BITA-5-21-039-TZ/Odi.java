import java.util.Scanner;
class Odi extends Patient {
    private int od_no;
    private String desease_type;
    public Odi(){

    }
    public Odi(int od_no,String desease_type,String name, String address){
        super(name,address);
        this.od_no=od_no;
        this.desease_type=desease_type;
    }
    public void setod_no(int od_no){
        this.od_no=od_no;
    }
    public int getod_no(){
        return od_no;
    }
    public void setdesease_type(String desease_type){
        this.desease_type=desease_type;
    }
    public String getdesease_type(){
        return desease_type;
    }
    @Override
    public String toString(){
        return "odi information is "+super.toString()+"the odi no is "+od_no+ "the desease type is "+desease_type; 
    }
    public static void main(String[] args) {
        Odi od = new Odi();
        Scanner mam=new Scanner(System.in);
        System.out.println("enter odi name");
        od.setname(mam.nextLine());
        System.out.println("enter address of odi");
        od.setaddress(mam.nextLine());
        System.out.println("enter  desease type");
        od.setdesease_type(mam.nextLine());
        System.out.println("enter  odi number ");
        od.setod_no(mam.nextInt());
        System.out.println(od.toString());
    }
}
