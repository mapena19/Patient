class Registration{
	private String name;
	public Registration(){
		this.name = name;
	}
	public void setname(String name){
		this.name = name;
	}
	public String getname(){
		return name;
	}
	@Override
	public String toString(){
		return "my name is" +name;
	}
}