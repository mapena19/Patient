import java.util.Scanner;
class Phamacy extends Patient {
    private String drug;
    public Phamacy(){

    }
    public Phamacy(String drug,String name, String address){
        super(name,address);
        this.drug=drug;
    }
    public void setdrug(String drug){
        this.drug=drug;
    }
    public String getdrug(){
        return drug;
    }
    @Override
    public String toString(){
        return "pharmacy information is "+super.toString()+"the  drug is "+drug; 
    }
    public static void main(String[] args) {
        Phamacy pha = new Phamacy();
        Scanner mam=new Scanner(System.in);
        System.out.println("enter phamacy name");
        pha.setname(mam.nextLine());
        System.out.println("enter address of phamacy");
        pha.setaddress(mam.nextLine());
        System.out.println("enter  drug");
        pha.setdrug(mam.nextLine());
        System.out.println(pha.toString());
    }
}
