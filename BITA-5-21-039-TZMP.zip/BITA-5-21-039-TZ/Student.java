import java.util.Scanner;
class Student extends Registration{
	private int std_id;
	private int phone;
	public Student(){

	}
	public Student(String name, int std_id, int phone){
        super(name)
		this.std_id = std_id;
		this.phone = phone;
	}
	public void setstd_id(int std_id){
		this.std_id = std_id;
	}
	public int getstd_id(){
		return std_id;
	}
	public void setphone(int phone){
		this.phone = phone;
	}
	public int getphone(){
		return phone;
	}
	@Override
	public String toString(){
        return "the name is"+name+"hjj "+std_id+ "tyrr"+phone;
	}
	public static void main(String[] args) {
		Student std = new Student();
		Scanner raya = new Scanner(System.in);
		System.out.println("enter student name");
		std.setname(raya.nextLine());
		System.out.println("enter student id number");
		std.setstd_id(raya.nextInt());
		System.out.println("enter student phonr number");
		std.setphone(raya.nextInt());
		System.out.println(raya.toString());

	}
}