import java.util.Scanner;
class Laboratory extends Patient {
    private String checkup_type;
    public Laboratory(){

    }
    public Laboratory(String checkup_type,String name, String address){
        super(name,address);
        this.checkup_type=checkup_type;
    }
    public void setcheckup_type(String checkup_type){
        this.checkup_type=checkup_type;
    }
    public int getcheckup_type(){
        return checkup_type;
    }
    @Override
    public String toString(){
        return "laboratory information "+super.toString()+"the checkup_type is "+checkup_type; 
    }
    public static void main(String[] args) {
        Laboratory lab = new Laboratory();
        Scanner mam=new Scanner(System.in);
        System.out.println("enter laboratory name");
        lab.setname(mam.nextLine());
        System.out.println("enter address of laboratory");
        lab.setaddress(mam.nextLine());
        System.out.println("enter  the checkup");
        lab.setcheckup_type(mam.nextLine());
        System.out.println(lab.toString());
    }
}
